
This directory contains 3rd party library dependencies of ProteoWizard.  Library 
packages and generated binary files that work properly with ProteoWizard that are 
archived here for convenience.  Documentation and latest packages may be found at 
their respective websites:

Boost C++ libraries: boost.org
gd graphics library: libgd.org
fftw library: fftw.org



