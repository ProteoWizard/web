Copyright 2008 Jurko Gospodnetic
Distributed under the Boost Software License, Version 1.0.
(See accompanying file LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt)


This example shows a very basic Boost Build project set up so it compiles a
single executable from a single source file.
