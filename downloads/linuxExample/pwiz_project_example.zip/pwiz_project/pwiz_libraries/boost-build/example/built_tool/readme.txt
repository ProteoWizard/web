
This example shows how to build an executable and then use it
for generating other targets. The 'tblgen' subdirectory builds
a tool, while the 'core' subdirectory uses that tool. Refer
to core/Jamfile.jam for detailed comments.